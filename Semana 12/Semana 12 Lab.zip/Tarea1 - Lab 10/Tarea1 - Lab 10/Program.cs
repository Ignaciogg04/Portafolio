﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tarea1___Lab_10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            TrianguloRectangulo objtriangulo = new TrianguloRectangulo();

            Console.WriteLine("Ingrese un cateto");
            double CatetoA = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Ingrese el angulo opuesto a este");
            double OpuestoA = Convert.ToDouble(Console.ReadLine());

            objtriangulo.SetCatetos(CatetoA, OpuestoA);
            objtriangulo.ObtenerDatos();

            Console.ReadKey();
        }
    }
}
