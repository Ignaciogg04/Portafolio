﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Actividad__8_semana_5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Mi segundo programa");

            Console.WriteLine("Ingrese su mombre");
            string sNombre = Console.ReadLine();

            Console.WriteLine("Ingrese su edad");
            string sEdad = Console.ReadLine();

            Console.WriteLine("Ingrese su carrera");
            string sCarrera = Console.ReadLine();

            Console.WriteLine("Ingrese su carné");
            string sCarné = Console.ReadLine();

            Console.WriteLine("Usted es " + sNombre + ", su edad es " + sEdad + ", actualmente está cursando la carrera " + sCarrera);
            Console.WriteLine("Su No. de carné es: " + sCarné);
            Console.ReadLine();
        }
    }
}
