﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tarea_1_semana_6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double n_Vo = 0, n_Vf = 0, n_a = 0, n_T = 0, n_Desconocida = 0;
            Console.WriteLine("Ingrese el valor que DESEA conocer: Vo = 1, Vf = 2, a = 3 ó T = 4");
            n_Desconocida = Convert.ToDouble(Console.ReadLine());

            if (n_Desconocida == 1)
            {
                Console.WriteLine("Ingrese el valor de Vf");
                n_Vf = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine("Ingrese el valor de a");
                n_a = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine("Ingrese el valor de T");
                n_T = Convert.ToDouble(Console.ReadLine());

                n_Desconocida = n_Vf - n_a * n_T;
                Console.WriteLine("El valor es " + n_Desconocida);
            }
            else if (n_Desconocida == 2)
            {
                Console.WriteLine("Ingrese el valor de Vo");
                n_Vo = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine("Ingrese el valor de a");
                n_a = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine("Ingrese el valor de T");
                n_T = Convert.ToDouble(Console.ReadLine());

                n_Desconocida = n_Vo + n_a*n_T;
                Console.WriteLine("El valor es " + n_Desconocida);
            }
            else if (n_Desconocida == 3)
            {
                Console.WriteLine("Ingrese el valor de Vf");
                n_Vf = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine("Ingrese el valor de Vo");
                n_Vo = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine("Ingrese el valor de T");
                n_T = Convert.ToDouble(Console.ReadLine());

                n_Desconocida = (n_Vf - n_Vo)/n_T;
                Console.WriteLine("El valor es " + n_Desconocida);
            }
            else if (n_Desconocida == 4)
            {
                Console.WriteLine("Ingrese el valor de Vf");
                n_Vf = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine("Ingrese el valor de a");
                n_a = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine("Ingrese el valor de Vo");
                n_Vo = Convert.ToDouble(Console.ReadLine());

                n_Desconocida = (n_Vf-n_Vo)/n_a;
                Console.WriteLine("El valor es " + n_Desconocida);

            }
            else
            {
                Console.WriteLine("ERROR");
            }

            
            Console.ReadKey();
        }
        
    }

}
